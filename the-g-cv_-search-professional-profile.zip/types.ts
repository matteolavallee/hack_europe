
export enum Category {
  EXPERIENCE = 'Experience',
  EDUCATION = 'Education',
  CERTIFICATION = 'Certification',
  PROJECTS = 'Projects'
}

export interface CVItem {
  id: string;
  category: Category;
  title: string;
  subtitle: string;
  url: string;
  date: string;
  description: string;
  fullDetails: string[];
  technologies?: string[];
  location?: string;
}

export interface Profile {
  name: string;
  tagline: string;
  avatar: string;
  email: string;
  phone?: string;
  location: string;
  links: {
    linkedin: string;
    github: string;
    portfolio: string;
  };
  summary: string;
  skills?: string[];
}
