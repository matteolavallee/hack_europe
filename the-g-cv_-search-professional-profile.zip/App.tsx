
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { CVItem, Category, Profile } from './types';
import Header from './components/Header';
import Tabs from './components/Tabs';
import ResultCard from './components/ResultCard';
import KnowledgePanel from './components/KnowledgePanel';
import DetailModal from './components/DetailModal';
import AdminDashboard from './components/AdminDashboard';

const EMPTY_PROFILE: Profile = {
  name: "",
  tagline: "",
  avatar: "",
  email: "",
  location: "",
  links: {
    linkedin: "",
    github: "",
    portfolio: ""
  },
  summary: "",
  skills: []
};

const App: React.FC = () => {
  const [profile, setProfile] = useState<Profile>(EMPTY_PROFILE);
  const [cvItems, setCvItems] = useState<CVItem[]>([]);
  const [activeTab, setActiveTab] = useState('All');
  const [selectedItem, setSelectedItem] = useState<CVItem | null>(null);
  const [showAdmin, setShowAdmin] = useState(true);
  const [featuredItemId, setFeaturedItemId] = useState<string | null>(null);
  const [isGenerated, setIsGenerated] = useState(false);

  const handleUpdateData = useCallback((newProfile: Profile, newItems: CVItem[]) => {
    setProfile(prev => ({
      ...prev,
      ...newProfile,
      links: { ...prev.links, ...newProfile.links },
      avatar: newProfile.avatar || prev.avatar 
    }));
    
    if (newItems) {
      setCvItems(newItems);

      if (newItems.length > 0 && !isGenerated) {
        const firstExp = newItems.find(i => i.category === Category.EXPERIENCE);
        setFeaturedItemId(firstExp?.id || newItems[0].id);
        setIsGenerated(true);
      }
    }
  }, [isGenerated]);

  const handleToggleFeatured = useCallback((id: string) => {
    setFeaturedItemId(id);
  }, []);

  // Effect to ensure we don't stay on a tab that has no items (e.g. after deletion)
  useEffect(() => {
    if (activeTab === 'All') return;
    
    const categoryMap: Record<string, Category> = {
      'Experience': Category.EXPERIENCE,
      'Education': Category.EDUCATION,
      'Certifications': Category.CERTIFICATION,
      'Projects': Category.PROJECTS
    };
    
    const category = categoryMap[activeTab];
    const hasItems = cvItems.some(item => item.category === category);
    
    if (!hasItems) {
      setActiveTab('All');
    }
  }, [cvItems, activeTab]);

  const filteredData = useMemo(() => {
    let data = cvItems;
    if (activeTab !== 'All') {
      const categoryMap: Record<string, Category> = {
        'Experience': Category.EXPERIENCE,
        'Education': Category.EDUCATION,
        'Certifications': Category.CERTIFICATION,
        'Projects': Category.PROJECTS
      };
      data = data.filter(item => item.category === categoryMap[activeTab]);
    }
    // Search filtering removed as search bar is now static
    return data;
  }, [activeTab, cvItems]);

  const featuredItem = useMemo(() => {
    return cvItems.find(i => i.id === featuredItemId) || null;
  }, [cvItems, featuredItemId]);

  const stats = useMemo(() => {
    const time = (Math.random() * 0.5 + 0.1).toFixed(2);
    return `About ${filteredData.length} results (${time} seconds)`;
  }, [filteredData]);

  if (showAdmin) {
    return (
      <AdminDashboard 
        currentProfile={profile}
        cvItems={cvItems}
        featuredItemId={featuredItemId}
        isGenerated={isGenerated}
        onClose={() => setShowAdmin(false)} 
        onUpdate={handleUpdateData}
        onToggleFeatured={handleToggleFeatured}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white selection:bg-blue-100 flex flex-col">
      <Header 
        profile={profile}
      />
      <Tabs activeTab={activeTab} onTabChange={setActiveTab} cvItems={cvItems} />
      
      <main className="px-4 md:px-8 lg:px-[180px] pt-4 pb-24 flex flex-col lg:flex-row gap-8 lg:gap-16 flex-grow">
        <div className="flex-grow max-w-[652px]">
          <p className="text-[#70757a] text-sm mb-6 font-normal">{stats}</p>
          
          {filteredData.length > 0 ? (
            <div className="space-y-2">
              {featuredItem && activeTab === 'All' && filteredData.some(i => i.id === featuredItemId) && (
                <div className="mb-8 p-6 border border-[#dadce0] rounded-xl shadow-sm hover:shadow-md transition-shadow">
                  <h4 className="text-[#202124] text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
                    <i className="fa-solid fa-star text-yellow-500"></i> Featured Spotlight
                  </h4>
                  <ResultCard item={featuredItem} onClick={setSelectedItem} />
                  <div className="border-t border-[#dadce0] mt-4 pt-4 text-[#1a73e8] hover:underline cursor-pointer text-sm font-medium" onClick={() => setActiveTab(featuredItem.category === Category.CERTIFICATION ? 'Certifications' : featuredItem.category)}>
                    Explore more in {featuredItem.category} →
                  </div>
                </div>
              )}

              {filteredData.map(item => {
                if (activeTab === 'All' && item.id === featuredItemId) return null;
                return (
                  <ResultCard 
                    key={item.id} 
                    item={item} 
                    onClick={setSelectedItem} 
                  />
                );
              })}
            </div>
          ) : (
            <div className="mt-12 text-[#202124]">
              <p>No records found for the selected category.</p>
            </div>
          )}
        </div>

        <aside className="hidden lg:block sticky top-32 h-fit space-y-6">
          <KnowledgePanel profile={profile} cvItems={cvItems} />
        </aside>
      </main>

      <footer className="bg-[#f2f2f2] border-t border-[#dadce0] mt-auto">
        <div className="px-4 md:px-8 lg:px-[180px] py-4 text-[#70757a] text-[14px] border-b border-[#dadce0]">
           <span className="font-bold">Privacy:</span> Your data is processed locally using Gemini AI.
        </div>
        <div className="px-4 md:px-8 lg:px-[180px] py-4 flex flex-wrap gap-x-8 gap-y-2 text-[14px] text-[#70757a]">
          <a href="#" className="hover:text-[#202124] hover:underline cursor-default" onClick={(e) => e.preventDefault()}>Edit Profile</a>
          <a href="#" className="hover:text-[#202124] hover:underline cursor-default" onClick={(e) => e.preventDefault()}>Help</a>
          <a href="#" className="hover:text-[#202124] hover:underline cursor-default" onClick={(e) => e.preventDefault()}>Feedback</a>
        </div>
      </footer>

      {/* Big prominent Admin redirection button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => setShowAdmin(true)}
          className="bg-[#1a73e8] text-white px-6 py-3 rounded-full shadow-2xl hover:bg-[#1557b0] transition-all flex items-center gap-3 font-bold active:scale-95 group"
        >
          <i className="fa-solid fa-user-gear group-hover:rotate-45 transition-transform"></i>
          <span>Admin Dashboard</span>
        </button>
      </div>

      <DetailModal 
        item={selectedItem} 
        onClose={() => setSelectedItem(null)} 
      />
    </div>
  );
};

export default App;
