
import { Category, CVItem, Profile } from './types';

export const PROFILE: Profile = {
  name: "Alex Rivera",
  tagline: "Building scalable digital futures with full-stack engineering excellence.",
  avatar: "https://picsum.photos/seed/alex/150/150",
  email: "alex.rivera@example.com",
  location: "San Francisco, CA",
  links: {
    linkedin: "https://linkedin.com/in/alex-rivera",
    github: "https://github.com/alexrivera",
    portfolio: "https://alexrivera.dev"
  },
  summary: "Senior Full Stack Engineer with over 8 years of experience in React, Node.js, and Cloud Architecture. Passionate about creating intuitive user experiences and highly performant backend systems.",
  skills: [
    "Full Stack Development",
    "Cloud Architecture (AWS)",
    "React & React Native",
    "Node.js & TypeScript",
    "System Design",
    "UI/UX Implementation",
    "CI/CD Pipelines",
    "Agile Leadership"
  ]
};

export const CV_DATA: CVItem[] = [
  {
    id: "exp-1",
    category: Category.EXPERIENCE,
    title: "Senior Full Stack Engineer",
    subtitle: "TechGiant Corporation",
    url: "https://techgiant.com/careers/engineering",
    date: "Jan 2021 - Present",
    description: "Leading the core platform team focusing on microservices architecture and React design systems. Improved load times by 40% across all legacy apps.",
    fullDetails: [
      "Architected a scalable micro-frontend framework used by 50+ internal developers.",
      "Mentored 10 junior and mid-level engineers, fostering a culture of test-driven development.",
      "Implemented CI/CD pipelines reducing deployment time from hours to minutes.",
      "Collaborated with UX teams to implement high-fidelity interactive components."
    ],
    technologies: ["React", "TypeScript", "Node.js", "AWS", "Kubernetes"],
    location: "San Francisco, CA"
  },
  {
    id: "exp-2",
    category: Category.EXPERIENCE,
    title: "Software Engineer II",
    subtitle: "Innova Startup Lab",
    url: "https://innovalab.io/team",
    date: "June 2018 - Dec 2020",
    description: "Developed and maintained several SaaS products using React and Python/Django. Specialized in real-time data visualization and high-performance APIs.",
    fullDetails: [
      "Developed a real-time analytics dashboard using WebSocket and D3.js.",
      "Optimized database queries in PostgreSQL, reducing server response time by 30%.",
      "Built a secure authentication system supporting OAuth2 and SSO.",
      "Integrated 3rd party APIs for payment processing and CRM automation."
    ],
    technologies: ["Python", "Django", "React", "PostgreSQL", "Redis"],
    location: "Austin, TX"
  },
  {
    id: "edu-1",
    category: Category.EDUCATION,
    title: "M.S. in Computer Science",
    subtitle: "Stanford University",
    url: "https://cs.stanford.edu/degrees/masters",
    date: "2016 - 2018",
    description: "Specialized in Artificial Intelligence and Human-Computer Interaction. GPA 3.9/4.0.",
    fullDetails: [
      "Thesis: 'Optimizing Neural Networks for Mobile Edge Computing'.",
      "Teaching Assistant for 'Introduction to Web Applications'.",
      "Active member of the Stanford Blockchain Group."
    ],
    location: "Stanford, CA"
  },
  {
    id: "cert-1",
    category: Category.CERTIFICATION,
    title: "AWS Certified Solutions Architect – Professional",
    subtitle: "Amazon Web Services (AWS)",
    url: "https://aws.amazon.com/certification/certified-solutions-architect-professional/",
    date: "Issued Aug 2022",
    description: "Advanced validation of technical skills and experience in designing distributed applications and systems on the AWS platform.",
    fullDetails: [
      "Demonstrated ability to design complex, multi-tier cloud architectures.",
      "Validated skills in high availability, scalability, and disaster recovery.",
      "Strategic planning for cloud migrations and cost optimization."
    ]
  },
  {
    id: "proj-1",
    category: Category.PROJECTS,
    title: "OpenSource Dashboard Library",
    subtitle: "Github / Personal Project",
    url: "https://github.com/alexrivera/react-clean-charts",
    date: "2023",
    description: "A lightweight, accessible, and themeable React charting library built with SVG and Tailwind CSS.",
    fullDetails: [
      "Reached 2k+ stars on GitHub within the first 6 months.",
      "Implemented a tree-shakable architecture for minimal bundle size.",
      "Automated documentation generation using Storybook."
    ],
    technologies: ["React", "Tailwind", "D3", "Vite"]
  }
];
