
import { GoogleGenAI, Type } from "@google/genai";

const cvSchema = {
  type: Type.OBJECT,
  properties: {
    profile: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING },
        tagline: { type: Type.STRING, description: "A catchy professional tagline. MUST BE UNDER 60 CHARACTERS." },
        summary: { type: Type.STRING },
        location: { type: Type.STRING },
        email: { type: Type.STRING },
        phone: { type: Type.STRING },
        links: {
          type: Type.OBJECT,
          properties: {
            linkedin: { type: Type.STRING },
            github: { type: Type.STRING },
            portfolio: { type: Type.STRING },
          },
          required: ["linkedin", "github", "portfolio"]
        },
        skills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "A list of 8-12 core competencies, skills, or technologies. Short phrases."
        }
      },
      required: ["name", "tagline", "summary", "location", "email", "links", "skills"]
    },
    items: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          category: { 
            type: Type.STRING, 
            description: "Must be one of: Experience, Education, Certification, Projects" 
          },
          title: { type: Type.STRING },
          subtitle: { type: Type.STRING, description: "Company or School name" },
          url: { type: Type.STRING },
          date: { type: Type.STRING },
          description: { type: Type.STRING },
          fullDetails: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Bullet points for the experience"
          },
          technologies: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Relevant skills or technologies for this specific entry"
          },
          location: { type: Type.STRING }
        },
        required: ["id", "category", "title", "subtitle", "date", "description", "fullDetails"]
      }
    }
  },
  required: ["profile", "items"]
};

const SYSTEM_INSTRUCTION = `
  You are a high-fidelity data extraction engine. 
  TASK: Convert the provided CV/Resume into a structured JSON format.
  
  STRICT RULES:
  1. NO HALLUCINATIONS: You MUST NOT invent, guess, or infer personal identity details (names, contact info).
  2. EXACT CONTENT: Experience details must come directly from the source.
  3. INTELLIGENT SKILL ANALYSIS: If a dedicated 'Skills' section is missing, ANALYZE the experience and education descriptions to extract relevant 'core skills'. Populate these into the 'technologies' arrays AND the top-level 'skills' array.
  4. CATEGORY MAPPING: Degrees -> 'Education', Work -> 'Experience', Certificates -> 'Certification', Projects -> 'Projects'.
  5. TAGLINE: Create a catchy, professional one-sentence tagline. 
     IMPORTANT: The tagline MUST NOT exceed 60 characters to ensure it fits perfectly in the search bar.
  6. SKILLS: Extract a list of key skills for the profile skills section.
`;

export const parseCVContent = async (content: { text?: string; file?: { data: string; mimeType: string } }): Promise<any> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const parts: any[] = [];
  if (content.text) {
    parts.push({ text: `Provided CV Text:\n\n${content.text}` });
  }
  if (content.file) {
    parts.push({
      inlineData: {
        data: content.file.data,
        mimeType: content.file.mimeType
      }
    });
    parts.push({ text: "Please extract the structured CV data from this file." });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: cvSchema,
      },
    });

    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    console.error("CV Parsing Error:", error);
    if (error.message?.includes("Requested entity was not found")) {
      throw new Error("The selected AI model is currently unavailable. Please ensure your API key has access to gemini-3-flash-preview.");
    }
    throw new Error("Failed to parse CV. Ensure the file is a valid PDF or the text is readable.");
  }
};
