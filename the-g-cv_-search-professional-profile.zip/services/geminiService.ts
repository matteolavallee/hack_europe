
import { GoogleGenAI } from "@google/genai";
import { Profile, CVItem } from "../types";

export const getGeminiInsights = async (userPrompt: string, profile: Profile, items: CVItem[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const context = `
    You are an AI career assistant for ${profile.name}. 
    Candidate Info:
    Summary: ${profile.summary}
    Tagline: ${profile.tagline}
    Experience and Education:
    ${items.map(item => `- ${item.category}: ${item.title} at ${item.subtitle} (${item.date}). Description: ${item.description}`).join('\n')}
    
    Answer the following user query about this candidate in a professional, concise, and helpful tone.
    DO NOT invent facts. Only use provided data.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `${context}\n\nUser Question: ${userPrompt}`,
    });

    return response.text || "I'm sorry, I couldn't process that request at the moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error communicating with the AI. Please try again later.";
  }
};
