import React, { useState } from 'react';
import { Profile, CVItem } from '../types';
import ContactModal from './ContactModal';

interface KnowledgePanelProps {
  profile: Profile;
  cvItems: CVItem[];
}

const KnowledgePanel: React.FC<KnowledgePanelProps> = ({ profile, cvItems }) => {
  const [showContact, setShowContact] = useState(false);

  const hasWebsite = profile.links.portfolio && profile.links.portfolio.length > 5;
  const hasContact = profile.email || profile.phone;
  const hasLinkedin = profile.links.linkedin && profile.links.linkedin.length > 5;

  return (
    <>
      <div className="w-full md:w-[370px] bg-white border border-[#dadce0] rounded-lg overflow-hidden h-fit shadow-none">
        <div className="flex items-center justify-between p-4 border-b border-[#dadce0]">
          <div className="flex-grow pr-4">
            <h2 className="text-[28px] font-normal text-[#202124] mb-0 leading-tight uppercase tracking-tight">{profile.name}</h2>
            <p className="text-[#70757a] text-sm mt-1">Professional Profile</p>
          </div>
          <div className="w-[100px] h-[100px] rounded-2xl overflow-hidden border border-gray-100 flex-shrink-0">
             {profile.avatar ? (
               <img src={profile.avatar} alt={profile.name} className="w-full h-full object-cover" />
             ) : (
               <div className="w-full h-full bg-[#e8f0fe] text-[#1a73e8] flex items-center justify-center font-bold text-2xl">
                 {profile.name.split(' ').map(n => n[0]).join('')}
               </div>
             )}
          </div>
        </div>

        <div className="p-4">
          <div className="grid grid-cols-2 gap-2 mb-6">
            {hasWebsite && (
              <a 
                href={profile.links.portfolio} 
                target="_blank" 
                className="py-1.5 border border-[#dadce0] rounded-full text-[#1a73e8] text-xs font-medium hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-globe"></i> Website
              </a>
            )}
            {hasContact && (
              <button 
                onClick={() => setShowContact(true)}
                className="py-1.5 border border-[#dadce0] rounded-full text-[#1a73e8] text-xs font-medium hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-envelope"></i> Contact
              </button>
            )}
            {hasLinkedin && (
              <a 
                href={profile.links.linkedin} 
                target="_blank" 
                className="py-1.5 border border-[#dadce0] rounded-full text-[#1a73e8] text-xs font-medium hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
              >
                <i className="fa-brands fa-linkedin"></i> LinkedIn
              </a>
            )}
            <button className="py-1.5 border border-[#dadce0] rounded-full text-[#1a73e8] text-xs font-medium hover:bg-blue-50 transition-colors flex items-center justify-center gap-2">
              <i className="fa-solid fa-share-nodes"></i> Share
            </button>
          </div>

          <p className="text-[14px] leading-[1.58] text-[#3c4043] mb-6">
            {profile.summary} <span className="text-[#70757a] cursor-pointer hover:underline">Reference</span>
          </p>

          {profile.skills && profile.skills.length > 0 && (
            <div className="mb-6">
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill, index) => (
                  <span 
                    key={index}
                    className="px-3 py-1 bg-[#f1f3f4] text-[#3c4043] rounded-full text-xs font-medium hover:bg-[#e8eaed] transition-colors cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4 text-[14px] border-t border-[#dadce0] pt-4">
            <div className="flex gap-2">
              <span className="font-bold text-[#202124] min-w-[80px]">Location:</span>
              <span className="text-[#1a73e8] hover:underline cursor-pointer">{profile.location}</span>
            </div>
            {profile.links.linkedin && (
              <div className="flex gap-2">
                <span className="font-bold text-[#202124] min-w-[80px]">LinkedIn:</span>
                <a href={profile.links.linkedin} target="_blank" className="text-[#1a73e8] hover:underline truncate">View Profile</a>
              </div>
            )}
          </div>
        </div>
      </div>
      {showContact && <ContactModal profile={profile} onClose={() => setShowContact(false)} />}
    </>
  );
};

export default KnowledgePanel;