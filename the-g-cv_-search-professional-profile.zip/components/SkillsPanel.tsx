
import React from 'react';

interface SkillsPanelProps {
  skills?: string[];
}

const SkillsPanel: React.FC<SkillsPanelProps> = ({ skills = [] }) => {
  if (!skills || skills.length === 0) return null;

  return (
    <div className="w-full md:w-[370px] bg-white border border-[#dadce0] rounded-lg overflow-hidden h-fit mt-6">
      <div className="p-4 border-b border-[#dadce0]">
        <h2 className="text-[18px] font-normal text-[#202124] leading-tight">People also ask about skills</h2>
      </div>

      <div className="p-0">
        {skills.map((skill, index) => (
          <div 
            key={index} 
            className="px-4 py-3 border-b border-[#dadce0] last:border-b-0 flex items-center justify-between cursor-pointer group hover:bg-[#f1f3f4] transition-colors"
          >
            <div className="text-[14px] text-[#202124] group-hover:text-[#1a0dab] font-medium">
              {skill}
            </div>
            <i className="fa-solid fa-chevron-down text-[#70757a] text-xs"></i>
          </div>
        ))}
      </div>
      
      <div className="p-4 bg-[#f8f9fa] border-t border-[#dadce0]">
        <div className="text-[14px] text-[#70757a] italic">
          * Skills verified by experience
        </div>
      </div>
    </div>
  );
};

export default SkillsPanel;
