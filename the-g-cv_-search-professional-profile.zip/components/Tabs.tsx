
import React from 'react';
import { CVItem, Category } from '../types';

interface TabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  cvItems: CVItem[];
}

const Tabs: React.FC<TabsProps> = ({ activeTab, onTabChange, cvItems }) => {
  const tabs = [
    { name: 'All', icon: 'fa-magnifying-glass' },
    { name: 'Experience', icon: 'fa-briefcase' },
    { name: 'Education', icon: 'fa-graduation-cap' },
    { name: 'Certifications', icon: 'fa-certificate' },
    { name: 'Projects', icon: 'fa-laptop-code' }
  ];

  const visibleTabs = tabs.filter(tab => {
    if (tab.name === 'All') return true;
    
    // Map tab name to Category for check
    const categoryMap: Record<string, string> = {
      'Experience': Category.EXPERIENCE,
      'Education': Category.EDUCATION,
      'Certifications': Category.CERTIFICATION,
      'Projects': Category.PROJECTS
    };
    
    const category = categoryMap[tab.name];
    return cvItems.some(item => item.category === category);
  });

  return (
    <div className="px-4 md:px-8 lg:px-[180px] border-b border-gray-200">
      <div className="flex items-center gap-6 md:gap-8 overflow-x-auto no-scrollbar pt-1">
        {visibleTabs.map((tab) => (
          <div
            key={tab.name}
            onClick={() => onTabChange(tab.name)}
            className={`flex items-center gap-2 pb-3.5 pt-4 text-sm cursor-pointer whitespace-nowrap transition-colors relative ${
              activeTab === tab.name 
                ? 'text-[#1a73e8]' 
                : 'text-[#70757a] hover:text-[#202124]'
            }`}
          >
            <i className={`fa-solid ${tab.icon} text-[13px] ${activeTab === tab.name ? 'text-[#1a73e8]' : 'text-[#70757a]'}`}></i>
            <span className="font-medium">{tab.name}</span>
            {activeTab === tab.name && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#1a73e8]"></div>
            )}
          </div>
        ))}
        <div className="flex items-center gap-2 pb-3.5 pt-4 text-sm text-[#70757a] cursor-pointer ml-4">
           <i className="fa-solid fa-ellipsis-vertical"></i>
           <span className="font-medium">More</span>
        </div>
      </div>
    </div>
  );
};

export default Tabs;
