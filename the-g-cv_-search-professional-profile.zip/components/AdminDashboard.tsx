
import React, { useState, useRef, useMemo } from 'react';
import { parseCVContent } from '../services/cvParserService';
import { Profile, CVItem, Category } from '../types';
import ResultCard from './ResultCard';

interface AdminDashboardProps {
  onUpdate: (profile: Profile, items: CVItem[]) => void;
  onClose: () => void;
  currentProfile: Profile;
  cvItems: CVItem[];
  featuredItemId: string | null;
  onToggleFeatured: (id: string) => void;
  isGenerated: boolean;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  onUpdate, 
  onClose, 
  currentProfile, 
  cvItems, 
  featuredItemId, 
  onToggleFeatured,
  isGenerated 
}) => {
  const [cvText, setCvText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [photoPreview, setPhotoPreview] = useState(currentProfile.avatar);
  const [showDonePopup, setShowDonePopup] = useState(false);
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);
  const [adminCategoryTab, setAdminCategoryTab] = useState<string>('All');
  const [newSkillInput, setNewSkillInput] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const setupPdfInputRef = useRef<HTMLInputElement>(null);
  const managePdfInputRef = useRef<HTMLInputElement>(null);

  const triggerDone = () => {
    setShowDonePopup(true);
    setTimeout(() => setShowDonePopup(false), 3000);
  };

  const updateProfile = (updates: Partial<Profile>) => {
    onUpdate({ ...currentProfile, ...updates }, cvItems);
  };

  const updateItem = (index: number, updates: Partial<CVItem>) => {
    const newItems = [...cvItems];
    newItems[index] = { ...newItems[index], ...updates };
    onUpdate(currentProfile, newItems);
  };

  const deleteItem = (index: number) => {
    const newItems = cvItems.filter((_, i) => i !== index);
    onUpdate(currentProfile, newItems);
    setEditingItemIndex(null);
  };

  const moveItem = (index: number, direction: 'up' | 'down') => {
    const newItems = [...cvItems];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newItems.length) return;
    
    // Swap items
    const temp = newItems[index];
    newItems[index] = newItems[targetIndex];
    newItems[targetIndex] = temp;
    
    onUpdate(currentProfile, newItems);
    // Adjust editing index if necessary
    if (editingItemIndex === index) setEditingItemIndex(targetIndex);
    else if (editingItemIndex === targetIndex) setEditingItemIndex(index);
  };

  const addNewItem = () => {
    const newItem: CVItem = {
      id: `item-${Date.now()}`,
      category: adminCategoryTab !== 'All' && adminCategoryTab !== 'Skills' ? adminCategoryTab as Category : Category.EXPERIENCE,
      title: "New Position",
      subtitle: "Company Name",
      url: "",
      date: "2024 - Present",
      description: "Short description of your role.",
      fullDetails: ["Key achievement 1"],
      technologies: ["Skill"],
      location: "Location"
    };
    onUpdate(currentProfile, [...cvItems, newItem]);
    setEditingItemIndex(cvItems.length);
  };

  const handleAddSkill = () => {
    if (!newSkillInput.trim()) return;
    const currentSkills = currentProfile.skills || [];
    updateProfile({ skills: [...currentSkills, newSkillInput.trim()] });
    setNewSkillInput('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    const currentSkills = currentProfile.skills || [];
    updateProfile({ skills: currentSkills.filter(s => s !== skillToRemove) });
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setPhotoPreview(base64);
        updateProfile({ avatar: base64 });
        e.target.value = ''; // Reset to allow re-selection
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    setError(null);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = (reader.result as string).split(',')[1];
        const result = await parseCVContent({ file: { data: base64, mimeType: file.type } });
        onUpdate({ ...result.profile, avatar: photoPreview || result.profile.avatar }, result.items);
        triggerDone();
        e.target.value = ''; // Reset to allow re-selection
      } catch (err: any) {
        setError("Error parsing PDF. Please ensure it is a valid text-based PDF.");
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleTextProcess = async () => {
    if (!cvText.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const result = await parseCVContent({ text: cvText });
      onUpdate({ ...result.profile, avatar: photoPreview || result.profile.avatar }, result.items);
      triggerDone();
    } catch (err: any) {
      setError(err.message || "An error occurred during parsing.");
    } finally {
      setLoading(false);
    }
  };

  const filteredAdminItems = useMemo(() => {
    if (adminCategoryTab === 'Skills') return [];
    return cvItems.map((item, originalIndex) => ({ ...item, originalIndex }))
      .filter(item => adminCategoryTab === 'All' || item.category === adminCategoryTab);
  }, [cvItems, adminCategoryTab]);

  const inputClass = "w-full bg-[#3c4043] text-white border-none rounded p-3 focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-shadow";
  const labelClass = "block text-[11px] font-bold text-gray-400 uppercase mb-1.5 tracking-wider";

  const renderLogo = (name: string) => {
    const googleColors = ['#4285F4', '#EA4335', '#FBBC05', '#4285F4', '#34A853', '#EA4335'];
    const cleanName = name || "YourName";
    return (
      <div className="flex items-center gap-0.5 select-none overflow-hidden">
        {cleanName.replace(/\s/g, '').split('').map((char, i) => (
          <span key={i} style={{ color: googleColors[i % googleColors.length] }} className="font-bold text-xl tracking-tighter">
            {char}
          </span>
        ))}
      </div>
    );
  };

  const adminTabs = ['All', ...Object.values(Category), 'Skills'];

  return (
    <div className="min-h-screen bg-[#f8f9fa] pb-20">
      {showDonePopup && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[300] bg-[#1e8e3e] text-white px-8 py-3 rounded-full shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-500">
          <i className="fa-solid fa-circle-check text-xl"></i>
          <span className="font-bold tracking-wide uppercase text-sm">{isGenerated ? 'Profile Updated!' : 'Profile Generated!'}</span>
        </div>
      )}

      <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between sticky top-0 z-50 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 font-bold text-2xl tracking-tighter cursor-pointer" onClick={() => !isGenerated && window.location.reload()}>
            <span className="text-[#4285F4]">G</span><span className="text-[#EA4335]">C</span><span className="text-[#FBBC05]">V</span><span className="text-[#34A853]"> Builder</span>
          </div>
          <span className="px-2 py-0.5 bg-blue-50 text-[#1a73e8] text-[10px] font-bold rounded uppercase">{isGenerated ? 'Admin Mode' : 'Beta'}</span>
        </div>
        {isGenerated && (
          <button onClick={onClose} className="bg-[#1a73e8] text-white px-8 py-2.5 rounded-full font-medium hover:bg-[#1557b0] transition-all shadow-md flex items-center gap-2 active:scale-95">
            Launch Profile <i className="fa-solid fa-arrow-right text-xs"></i>
          </button>
        )}
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {!isGenerated ? (
          <div key="setup-layout" className="grid grid-cols-1 lg:grid-cols-12 gap-12 animate-in fade-in duration-500">
            <div className="lg:col-span-7 space-y-8">
              <section className="bg-white border border-[#dadce0] rounded-2xl p-8 shadow-sm">
                <h2 className="text-2xl font-normal text-[#202124] mb-2">Upload your Resume</h2>
                <p className="text-gray-500 text-sm mb-8">Let AI build your search-styled career story in seconds.</p>
                
                <div className="space-y-6">
                  <div 
                    className={`p-10 border-2 border-dashed rounded-2xl text-center transition-all cursor-pointer group ${loading ? 'bg-gray-50 border-gray-200' : 'bg-blue-50/30 border-blue-200 hover:bg-blue-50 hover:border-blue-400'}`}
                    onClick={() => !loading && setupPdfInputRef.current?.click()}
                  >
                    <i className={`fa-solid ${loading ? 'fa-spinner fa-spin' : 'fa-file-pdf'} text-4xl text-blue-500 mb-4`}></i>
                    <p className="text-lg font-medium text-gray-800">Upload PDF Resume</p>
                    <p className="text-sm text-gray-500 mt-1">AI will extract your experience instantly.</p>
                    <input type="file" ref={setupPdfInputRef} onChange={handlePdfUpload} className="hidden" accept=".pdf" />
                  </div>

                  <div className="relative py-2">
                    <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-100"></div></div>
                    <span className="relative bg-white px-4 text-xs font-bold text-gray-400 uppercase left-1/2 -translate-x-1/2">Alternative</span>
                  </div>

                  <textarea
                    className="w-full h-32 p-4 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-blue-500 outline-none text-sm transition-all"
                    placeholder="Or paste your resume text here..."
                    value={cvText}
                    onChange={(e) => setCvText(e.target.value)}
                  />
                  <button
                    onClick={handleTextProcess}
                    disabled={loading || !cvText.trim()}
                    className="w-full py-4 bg-gray-900 text-white rounded-xl font-bold hover:bg-black transition-all disabled:bg-gray-300 shadow-lg"
                  >
                    {loading ? 'Processing with AI...' : 'Generate My Search Profile'}
                  </button>
                </div>
                {error && <p className="mt-4 text-red-600 text-sm flex items-center gap-2 bg-red-50 p-3 rounded-lg"><i className="fa-solid fa-circle-exclamation"></i> {error}</p>}
              </section>
            </div>

            <div className="lg:col-span-5">
              <div className="sticky top-28 space-y-6">
                <div className="flex items-center justify-between px-2">
                  <h3 className="font-bold text-sm uppercase tracking-widest text-gray-400">Live Preview Demo</h3>
                </div>
                <div className="bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden min-h-[500px] flex flex-col items-center justify-center p-8">
                   <div className="text-center p-12 text-gray-300">
                      <i className="fa-solid fa-search text-6xl mb-4"></i>
                      <p className="text-sm italic">Generation Preview will appear here</p>
                   </div>
                   {photoPreview && (
                     <div className="mt-4 flex items-center gap-3 p-4 bg-blue-50/50 rounded-xl border border-blue-100 w-full animate-in slide-in-from-bottom-2">
                        <img src={photoPreview} className="w-10 h-10 rounded-full object-cover" />
                        <div className="text-left">
                          <p className="text-xs font-bold text-blue-600">Photo Attached</p>
                          <p className="text-[10px] text-blue-400">Ready for profile generation</p>
                        </div>
                     </div>
                   )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div key="management-layout" className="grid grid-cols-1 lg:grid-cols-12 gap-12 animate-in fade-in duration-500">
            <div className="lg:col-span-7 space-y-8">
              <section className="bg-white border border-[#dadce0] rounded-3xl p-8 shadow-sm">
                <h2 className="text-xl font-medium text-[#202124] mb-8 flex items-center gap-3">
                  <i className="fa-solid fa-user-gear text-blue-500"></i> Identity & Contact
                </h2>
                
                <div className="flex flex-col md:flex-row gap-8 items-start mb-8">
                  <div className="relative group shrink-0" onClick={() => fileInputRef.current?.click()}>
                    <div className="w-32 h-32 rounded-3xl overflow-hidden border border-gray-100 group-hover:border-blue-500 transition-all shadow-md bg-gray-50 flex items-center justify-center cursor-pointer">
                      {photoPreview ? <img src={photoPreview} className="w-full h-full object-cover" alt="Avatar" /> : <i className="fa-solid fa-image text-gray-300 text-4xl"></i>}
                    </div>
                    <div className="absolute bottom-1 right-1 bg-white border border-gray-200 w-8 h-8 rounded-full flex items-center justify-center text-[#1a73e8] shadow-lg">
                      <i className="fa-solid fa-pen text-[10px]"></i>
                    </div>
                    <input type="file" ref={fileInputRef} onChange={handlePhotoChange} className="hidden" accept="image/*" />
                  </div>
                  
                  <div className="flex-grow w-full space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div key="name-field">
                        <label className={labelClass}>Full Name</label>
                        <input type="text" className={inputClass} value={currentProfile.name} onChange={(e) => updateProfile({ name: e.target.value })} />
                      </div>
                      <div key="tagline-field">
                        <label className={labelClass}>Catchy Tagline</label>
                        <input type="text" className={inputClass} value={currentProfile.tagline} onChange={(e) => updateProfile({ tagline: e.target.value })} />
                      </div>
                    </div>
                    <div key="summary-field">
                      <label className={labelClass}>Professional Summary</label>
                      <textarea className={`${inputClass} min-h-[100px] resize-y`} value={currentProfile.summary} onChange={(e) => updateProfile({ summary: e.target.value })} />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 pt-8 border-t border-gray-100">
                    <div key="email-field">
                      <label className={labelClass}>Email</label>
                      <input type="email" className={inputClass} value={currentProfile.email} onChange={(e) => updateProfile({ email: e.target.value })} />
                    </div>
                    <div key="phone-field">
                      <label className={labelClass}>Phone</label>
                      <input type="text" className={inputClass} value={currentProfile.phone} onChange={(e) => updateProfile({ phone: e.target.value })} />
                    </div>
                    <div key="linkedin-field">
                      <label className={labelClass}>LinkedIn URL</label>
                      <input type="text" className={inputClass} value={currentProfile.links.linkedin} onChange={(e) => updateProfile({ links: { ...currentProfile.links, linkedin: e.target.value } })} />
                    </div>
                    <div key="portfolio-field">
                      <label className={labelClass}>Website URL</label>
                      <input type="text" className={inputClass} value={currentProfile.links.portfolio} onChange={(e) => updateProfile({ links: { ...currentProfile.links, portfolio: e.target.value } })} />
                    </div>
                </div>
              </section>

              <section className="bg-white border border-[#dadce0] rounded-3xl shadow-sm overflow-hidden">
                <div className="p-8 border-b border-gray-100 flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <i className="fa-solid fa-list-check text-green-500"></i>
                    <h2 className="text-xl font-medium text-[#202124]">CV Items & Skills</h2>
                  </div>
                  {adminCategoryTab !== 'Skills' && (
                    <button onClick={addNewItem} className="text-sm font-medium text-[#1a73e8] hover:bg-blue-50 px-5 py-2.5 rounded-full border border-blue-100 transition-colors flex items-center gap-2">
                      <i className="fa-solid fa-plus"></i> Add New
                    </button>
                  )}
                </div>

                <div className="px-8 border-b border-gray-100 flex gap-6 overflow-x-auto no-scrollbar">
                   {adminTabs.map(tab => (
                     <button 
                       key={tab} 
                       onClick={() => setAdminCategoryTab(tab)}
                       className={`pb-4 pt-6 text-sm font-medium border-b-2 transition-all whitespace-nowrap ${adminCategoryTab === tab ? 'border-[#1a73e8] text-[#1a73e8]' : 'border-transparent text-gray-500 hover:text-gray-900'}`}
                     >
                       {tab}
                     </button>
                   ))}
                </div>

                <div className="divide-y divide-gray-100">
                  {adminCategoryTab === 'Skills' ? (
                    <div className="p-8 space-y-6">
                      <div className="flex gap-4">
                        <input 
                          type="text" 
                          placeholder="Add a new skill (e.g. 'Project Management' or 'React')"
                          className={inputClass}
                          value={newSkillInput}
                          onChange={(e) => setNewSkillInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleAddSkill()}
                        />
                        <button 
                          onClick={handleAddSkill}
                          disabled={!newSkillInput.trim()}
                          className="bg-[#1a73e8] text-white px-6 rounded font-bold hover:bg-[#1557b0] transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                        >
                          Add
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {(currentProfile.skills || []).map((skill, idx) => (
                           <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded border border-gray-200 group">
                             <span className="text-gray-800 font-medium">{skill}</span>
                             <button onClick={() => handleRemoveSkill(skill)} className="text-gray-400 hover:text-red-500 transition-colors">
                               <i className="fa-solid fa-trash-can"></i>
                             </button>
                           </div>
                        ))}
                        {(currentProfile.skills || []).length === 0 && (
                          <div className="col-span-2 text-center text-gray-400 py-8 italic">No skills added yet.</div>
                        )}
                      </div>
                    </div>
                  ) : (
                    filteredAdminItems.length > 0 ? filteredAdminItems.map((item) => (
                      <div key={item.id} className="p-6 hover:bg-gray-50/50 transition-colors relative group">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-grow cursor-pointer" onClick={() => setEditingItemIndex(editingItemIndex === item.originalIndex ? null : item.originalIndex)}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-[10px] font-bold uppercase bg-gray-100 px-2 py-0.5 rounded text-gray-500">{item.category}</span>
                              <span className="text-xs text-gray-400">{item.date}</span>
                            </div>
                            <h4 className="font-medium text-gray-900">{item.title}</h4>
                            <p className="text-sm text-gray-500">{item.subtitle}</p>
                          </div>
                          
                          <div className="flex items-center gap-1.5">
                            <div className="flex flex-col gap-0.5 mr-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button 
                                onClick={(e) => { e.stopPropagation(); moveItem(item.originalIndex, 'up'); }}
                                disabled={item.originalIndex === 0}
                                className="w-7 h-7 rounded bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-gray-100"
                                title="Move Up"
                              >
                                <i className="fa-solid fa-chevron-up text-[10px]"></i>
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); moveItem(item.originalIndex, 'down'); }}
                                disabled={item.originalIndex === cvItems.length - 1}
                                className="w-7 h-7 rounded bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-gray-100"
                                title="Move Down"
                              >
                                <i className="fa-solid fa-chevron-down text-[10px]"></i>
                              </button>
                            </div>

                            <button onClick={(e) => { e.stopPropagation(); onToggleFeatured(item.id); }} className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${featuredItemId === item.id ? 'text-yellow-500 bg-yellow-50 shadow-sm' : 'text-gray-300 hover:text-yellow-400 hover:bg-gray-100'}`}>
                              <i className="fa-solid fa-star text-sm"></i>
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); deleteItem(item.originalIndex); }} className="w-9 h-9 rounded-full flex items-center justify-center text-gray-300 hover:text-red-500 hover:bg-red-50 transition-colors">
                              <i className="fa-solid fa-trash-can text-sm"></i>
                            </button>
                          </div>
                        </div>
                        
                        {editingItemIndex === item.originalIndex && (
                          <div className="mt-6 pt-6 border-t border-gray-100 space-y-6 animate-in slide-in-from-top-2">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className={labelClass}>Title</label>
                                <input type="text" className={inputClass} value={item.title} onChange={(e) => updateItem(item.originalIndex, { title: e.target.value })} />
                              </div>
                              <div>
                                <label className={labelClass}>Subtitle</label>
                                <input type="text" className={inputClass} value={item.subtitle} onChange={(e) => updateItem(item.originalIndex, { subtitle: e.target.value })} />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className={labelClass}>Date</label>
                                <input type="text" className={inputClass} value={item.date} onChange={(e) => updateItem(item.originalIndex, { date: e.target.value })} />
                              </div>
                              <div>
                                <label className={labelClass}>Category</label>
                                <select className={`${inputClass} appearance-none cursor-pointer`} value={item.category} onChange={(e) => updateItem(item.originalIndex, { category: e.target.value as Category })}>
                                    {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                                </select>
                              </div>
                            </div>
                            <div>
                              <label className={labelClass}>Direct Link / URL</label>
                              <input type="text" className={inputClass} placeholder="https://..." value={item.url} onChange={(e) => updateItem(item.originalIndex, { url: e.target.value })} />
                            </div>
                            <div>
                              <label className={labelClass}>Description</label>
                              <textarea className={`${inputClass} min-h-[80px]`} value={item.description} onChange={(e) => updateItem(item.originalIndex, { description: e.target.value })} />
                            </div>
                            <div>
                              <label className={labelClass}>Skills (comma separated)</label>
                              <input type="text" className={inputClass} value={item.technologies?.join(', ')} onChange={(e) => updateItem(item.originalIndex, { technologies: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })} />
                            </div>
                          </div>
                        )}
                      </div>
                    )) : (
                      <div className="p-20 text-center text-gray-400">
                        <i className="fa-solid fa-folder-open text-4xl mb-4 opacity-20"></i>
                        <p className="text-sm">No items found in {adminCategoryTab}</p>
                      </div>
                    )
                  )}
                </div>
              </section>

              <section className="bg-blue-50/20 border border-blue-100 rounded-3xl p-8">
                <h2 className="text-lg font-medium text-[#1a73e8] mb-4 flex items-center gap-2">
                  <i className="fa-solid fa-wand-magic-sparkles"></i> AI Re-generation
                </h2>
                <div className="space-y-4">
                  <div className={`p-8 border-2 border-dashed border-blue-200 rounded-2xl text-center bg-white hover:bg-blue-50 transition-all cursor-pointer group`} onClick={() => !loading && managePdfInputRef.current?.click()}>
                    <i className={`fa-solid ${loading ? 'fa-spinner fa-spin' : 'fa-file-pdf'} text-3xl text-blue-500 mb-3`}></i>
                    <p className="text-sm font-medium text-gray-800">Overwrite from PDF</p>
                    <input type="file" ref={managePdfInputRef} onChange={handlePdfUpload} className="hidden" accept=".pdf" />
                  </div>
                  <textarea className="w-full h-32 p-4 bg-white border border-gray-200 rounded-2xl focus:border-blue-500 outline-none text-sm shadow-inner" placeholder="Paste text to re-generate everything..." value={cvText} onChange={(e) => setCvText(e.target.value)} />
                  <button onClick={handleTextProcess} disabled={loading || !cvText.trim()} className="w-full py-4 bg-[#1a73e8] text-white rounded-2xl font-bold hover:bg-[#1557b0] transition-all disabled:bg-gray-300 shadow-md">
                    {loading ? 'AI Working...' : 'Replace All Content'}
                  </button>
                </div>
              </section>
            </div>

            <div className="lg:col-span-5">
              <div className="sticky top-28 space-y-6">
                <div className="flex items-center justify-between px-2">
                  <h3 className="font-bold text-[10px] uppercase tracking-[0.2em] text-gray-400">Real-time Search Preview</h3>
                  <div className="flex gap-1.5"><div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div><span className="text-[10px] text-green-600 font-bold uppercase">Synced</span></div>
                </div>
                <div className="bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden min-h-[500px]">
                  <div className="bg-gray-50 border-b border-gray-100 p-4 flex gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div><div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div><div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                  </div>
                  <div className="p-6">
                    <div className="mb-6">
                      <div className="mb-4">
                        {renderLogo(currentProfile.name)}
                      </div>
                      <div className="h-10 w-full bg-white rounded-full border border-gray-200 shadow-sm flex items-center px-4 gap-3">
                        <i className="fa-solid fa-magnifying-glass text-gray-300 text-xs"></i><span className="text-xs text-gray-600 truncate">{currentProfile.tagline}</span>
                      </div>
                    </div>
                    <div className="space-y-6 scale-[0.95] origin-top">
                      <div className="space-y-8">
                         {featuredItemId && cvItems.find(i => i.id === featuredItemId) && (
                           <div className="p-4 border border-blue-100 bg-blue-50/20 rounded-2xl relative">
                              <p className="text-[9px] font-bold text-blue-500 uppercase tracking-widest mb-3">Featured Spot</p>
                              <ResultCard item={cvItems.find(i => i.id === featuredItemId)!} onClick={() => {}} />
                           </div>
                         )}
                         <div className="space-y-6">
                            {cvItems.slice(0, 3).map(item => item.id !== featuredItemId && <ResultCard key={item.id} item={item} onClick={() => {}} />)}
                         </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6 bg-gray-900 text-white rounded-2xl shadow-lg border border-gray-800">
                   <div className="flex items-center gap-3 mb-3">
                     <div className="w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-inner">
                       <i className="fa-solid fa-check text-[11px]"></i>
                     </div>
                     <h4 className="text-xs font-bold uppercase tracking-widest">Ready to Launch</h4>
                   </div>
                   <p className="text-[11px] text-gray-400 mb-5 leading-relaxed">Your profile is automatically synced. Click "Launch Profile" to share your search-styled career story.</p>
                   <button onClick={onClose} className="w-full py-3 bg-white text-gray-900 rounded-xl text-xs font-bold hover:bg-gray-100 transition-all shadow-lg active:scale-95">Final Review & Launch</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
