
import React from 'react';
import { Profile } from '../types';

interface HeaderProps {
  profile: Profile;
}

const Header: React.FC<HeaderProps> = ({ profile }) => {
  const getLogo = () => {
    const colors = ['#4285F4', '#EA4335', '#FBBC05', '#4285F4', '#34A853', '#EA4335'];
    const name = profile.name.replace(/\s/g, '');
    return (
      <div className="flex select-none">
        {name.split('').map((char, idx) => (
          <span 
            key={idx} 
            style={{ color: colors[idx % colors.length] }}
            className="inline-block transition-transform hover:-translate-y-1"
          >
            {char}
          </span>
        ))}
      </div>
    );
  };

  return (
    <div className="sticky top-0 bg-white border-b border-gray-200 z-50 pt-5 md:pt-7 pb-0 px-4 md:px-8 lg:px-12 flex flex-col md:flex-row items-center gap-4 md:gap-8">
      <div 
        className="text-[28px] md:text-[32px] font-medium whitespace-nowrap tracking-tight mb-2 md:mb-0 cursor-default"
      >
        {getLogo()}
      </div>

      <div className="relative w-full max-w-[692px] mb-2 md:mb-0">
        {/* Search bar is now a static container, not an input, to disable fake research */}
        <div className="flex items-center w-full px-5 py-3 bg-white border border-gray-200 rounded-full hover:shadow-lg transition-shadow group cursor-default">
          <i className="fa-solid fa-magnifying-glass text-[#9aa0a6] mr-4 text-sm"></i>
          
          <div className="flex-grow text-[16px] text-gray-800 bg-transparent truncate pr-4">
            {profile.tagline}
          </div>

          <div className="flex items-center gap-4 border-l border-gray-200 pl-4 ml-2">
             {/* Cross icon removed as requested */}
             
             {/* Google Audio/Mic Icon */}
             <svg focusable="false" viewBox="0 0 24 24" className="w-5 h-5 hidden md:block" style={{ color: '#4285f4' }}>
                <path fill="#4285f4" d="m12 15c1.66 0 3-1.31 3-2.92v-7.08c0-1.61-1.34-2.92-3-2.92s-3 1.31-3 2.92v7.08c0 1.61 1.34 2.92 3 2.92z"></path>
                <path fill="#34a853" d="m11 18.08v2.92h2v-2.92c3.34-.45 6-3.21 6-6.58h-2c0 2.45-1.99 4.47-4.5 4.47s-4.5-2.02-4.5-4.47h-2c0 3.37 2.66 6.13 6 6.58z"></path>
             </svg>
             <i className="fa-solid fa-magnifying-glass text-[#4285f4] text-lg md:block hidden"></i>
          </div>
        </div>
      </div>

      <div className="hidden md:flex ml-auto items-center gap-5 text-gray-600">
        <div className="p-2 hover:bg-gray-100 rounded-full cursor-default transition-colors">
          <svg className="w-6 h-6" viewBox="0 0 24 24"><path fill="currentColor" d="M6,8c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S4.9,8,6,8z M12,20c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S10.9,20,12,20z M6,20c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S4.9,20,6,20z M6,14c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S4.9,14,6,14z M12,14c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S10.9,14,12,14z M12,8c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S10.9,8,12,8z M18,8c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S16.9,8,18,8z M18,14c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S16.9,14,18,14z M18,20c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S16.9,20,18,20z"></path></svg>
        </div>
        <div className="w-8 h-8 rounded-full bg-[#1a73e8] text-white flex items-center justify-center text-xs font-bold border border-gray-200 cursor-default">
          {profile.name ? profile.name[0] : 'G'}
        </div>
      </div>
    </div>
  );
};

export default Header;
