
import React from 'react';
import { Profile } from '../types';

interface ContactModalProps {
  profile: Profile;
  onClose: () => void;
}

const ContactModal: React.FC<ContactModalProps> = ({ profile, onClose }) => {
  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm transition-all animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col transform transition-all animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
          <h3 className="text-lg font-medium text-[#202124]">Contact Information</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-black p-1">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>
        <div className="p-8 space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
              <i className="fa-solid fa-envelope"></i>
            </div>
            <div>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Email</p>
              <a href={`mailto:${profile.email}`} className="text-[#1a73e8] hover:underline">{profile.email}</a>
            </div>
          </div>
          {profile.phone && (
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
                <i className="fa-solid fa-phone"></i>
              </div>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Phone</p>
                <a href={`tel:${profile.phone}`} className="text-[#1a73e8] hover:underline">{profile.phone}</a>
              </div>
            </div>
          )}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-red-50 text-red-600 flex items-center justify-center">
              <i className="fa-solid fa-location-dot"></i>
            </div>
            <div>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Location</p>
              <p className="text-[#202124]">{profile.location}</p>
            </div>
          </div>
        </div>
        <div className="p-4 bg-gray-50 text-center">
          <button 
            onClick={onClose}
            className="text-sm font-medium text-[#1a73e8] px-6 py-2 rounded-full border border-[#dadce0] bg-white hover:bg-gray-100"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactModal;
