
import React from 'react';
import { CVItem } from '../types';

interface DetailModalProps {
  item: CVItem | null;
  onClose: () => void;
}

const DetailModal: React.FC<DetailModalProps> = ({ item, onClose }) => {
  if (!item) return null;

  // Simple check to ensure we have a link that isn't just a protocol
  const hasValidLink = item.url && item.url.trim().length > 8 && item.url !== "https://";

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm transition-all animate-in fade-in duration-300">
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col transform transition-all animate-in slide-in-from-bottom-8 duration-300"
      >
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#f8f9fa] border border-gray-100 flex items-center justify-center text-blue-600 shadow-sm">
              <i className={`fa-solid ${
                item.category === 'Experience' ? 'fa-briefcase' : 
                item.category === 'Education' ? 'fa-graduation-cap' : 
                'fa-file-lines'
              } text-xl`}></i>
            </div>
            <div>
              <h2 className="text-xl font-medium text-[#202124] leading-tight">{item.title}</h2>
              <p className="text-sm text-[#70757a] mt-1">{item.subtitle}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-black p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <i className="fa-solid fa-xmark text-2xl"></i>
          </button>
        </div>

        <div className="p-8 overflow-y-auto custom-scrollbar">
          <div className="flex flex-wrap gap-3 mb-8">
            <div className="flex items-center gap-2 text-[#4d5156] bg-[#f1f3f4] px-4 py-2 rounded-full text-sm font-medium">
              <i className="fa-regular fa-calendar-check"></i>
              <span>{item.date}</span>
            </div>
            {item.location && (
              <div className="flex items-center gap-2 text-[#4d5156] bg-[#f1f3f4] px-4 py-2 rounded-full text-sm font-medium">
                <i className="fa-solid fa-location-arrow"></i>
                <span>{item.location}</span>
              </div>
            )}
            {hasValidLink && (
              <a 
                href={item.url} 
                target="_blank" 
                className="flex items-center gap-2 text-white bg-[#1a73e8] px-5 py-2 rounded-full text-sm font-medium hover:bg-[#1557b0] transition-colors shadow-md"
              >
                <i className="fa-solid fa-arrow-up-right-from-square"></i>
                <span>Project Site</span>
              </a>
            )}
          </div>

          <div className="space-y-8">
            <section>
              <h3 className="text-xs font-bold text-[#70757a] uppercase tracking-[0.1em] mb-4">Context</h3>
              <p className="text-[#202124] leading-relaxed text-lg font-light">
                {item.description}
              </p>
            </section>

            <section>
              <h3 className="text-xs font-bold text-[#70757a] uppercase tracking-[0.1em] mb-4">Core Accomplishments</h3>
              <ul className="space-y-4">
                {item.fullDetails.map((detail, idx) => (
                  <li key={idx} className="flex gap-4 text-[#3c4043]">
                    <div className="mt-1.5 flex-shrink-0 w-2 h-2 rounded-full bg-[#1a73e8]"></div>
                    <span className="leading-relaxed">{detail}</span>
                  </li>
                ))}
              </ul>
            </section>

            {item.technologies && item.technologies.length > 0 && (
              <section>
                <h3 className="text-xs font-bold text-[#70757a] uppercase tracking-[0.1em] mb-4">Skill Stack</h3>
                <div className="flex flex-wrap gap-2">
                  {item.technologies.map(tech => (
                    <span 
                      key={tech} 
                      className="px-4 py-1.5 bg-white border border-[#dadce0] text-[#3c4043] rounded-full text-sm hover:border-[#1a73e8] hover:text-[#1a73e8] transition-all cursor-default"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>

        <div className="p-6 border-t border-gray-100 bg-[#f8f9fa] flex justify-between items-center">
          <div className="text-xs text-[#70757a]">
            Last updated: {new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
          </div>
          <button 
            onClick={onClose}
            className="px-8 py-2.5 bg-white border border-[#dadce0] text-[#1a73e8] rounded-full hover:bg-blue-50 transition-colors font-medium shadow-sm"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};

export default DetailModal;
