
import React from 'react';
import { CVItem } from '../types';

interface ResultCardProps {
  item: CVItem;
  onClick: (item: CVItem) => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ item, onClick }) => {
  const hasValidLink = item.url && item.url.trim().length > 8 && item.url !== "https://";

  return (
    <div className="mb-8 group max-w-[652px]">
      <div className="flex flex-col">
        {/* Favicon and Breadcrumb area */}
        <div className="flex items-center gap-3 mb-1.5 cursor-pointer" onClick={() => onClick(item)}>
          <div className="w-7 h-7 bg-gray-100 rounded-full flex items-center justify-center text-[10px] text-gray-500 overflow-hidden">
             {item.category === 'Experience' ? <i className="fa-solid fa-briefcase"></i> : <i className="fa-solid fa-graduation-cap"></i>}
          </div>
          <div className="flex flex-col overflow-hidden">
            <span className="text-[14px] text-[#202124] leading-tight truncate">{item.subtitle}</span>
            <div className="flex items-center text-[12px] text-[#4d5156] truncate">
              <span>{hasValidLink ? item.url.replace('https://', '') : 'profile.internal'}</span>
              <span className="mx-1">›</span>
              <span className="text-gray-500 capitalize">{item.category.toLowerCase()}</span>
            </div>
          </div>
        </div>

        {/* Title */}
        <h3 
          className="text-[20px] text-[#1a0dab] group-hover:underline cursor-pointer font-medium leading-tight mb-1"
          onClick={() => onClick(item)}
        >
          {item.title}
        </h3>

        {/* Snippet */}
        <div className="text-[14px] text-[#4d5156] leading-[1.58] mb-1">
          <span className="font-semibold text-[#5f6368]">{item.date} — </span>
          {item.description}
        </div>
        
        {item.technologies && (
          <div className="mt-2 flex flex-wrap gap-2 opacity-70">
            {item.technologies.slice(0, 3).map(tech => (
              <span key={tech} className="text-[12px] px-2 py-0.5 border border-gray-200 text-gray-500 rounded-sm italic">
                #{tech.toLowerCase()}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ResultCard;
